//
//  ViewController.swift
//  ISBNOpenLibraryOrg
//
//  Created by Daniel Vivanco Ruiz on 21/06/16.
//  Copyright © 2016 Daniel Vivanco Ruiz. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var isbnTextField: UITextField!
    @IBOutlet weak var tituloLabel: UILabel!
    @IBOutlet weak var autorLabel: UILabel!
    @IBOutlet weak var portadaView: UIImageView!
    @IBOutlet weak var portadaLabel: UILabel!

   
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
    }
    
    func consultaIBSN(){
        
//Comprobar que se infreso el ISBN
        
        if (isbnTextField.text?.isEmpty == true){
            let alert = UIAlertController(title: "Error", message:"Introduce un código ISBN", preferredStyle: .Alert)
            alert.addAction(UIAlertAction(title: "Aceptar", style: .Default) { _ in })
            self.presentViewController(alert, animated: true) { }
            
        }else{
            let isbn:String = isbnTextField.text!
            let urls = "https://openlibrary.org/api/books?jscmd=data&format=json&bibkeys=ISBN:" + isbn
            let url  = NSURL(string: urls)
            let datos:NSData? = NSData(contentsOfURL: url!)
            
            do {
                let json = try NSJSONSerialization.JSONObjectWithData(datos!, options: NSJSONReadingOptions.MutableLeaves)
//Titulo
                let dict1 = json as! NSDictionary
                let dict2 = dict1["ISBN:\(isbn)"] as! NSDictionary
                self.tituloLabel.text = dict2["title"] as! NSString as String
//Autor
                let array1 = dict2["authors"] as! NSArray
                let array2 = array1[0]
                self.autorLabel.text = array2["name"] as! NSString as String
//Cover
                
                let dict3 = dict2["cover"] as! NSDictionary!
                
                if dict3 != nil {
                    let urlImagen = dict3["medium"] as! NSString! as String
                    let urlImagen2 = NSURL(string: urlImagen)
                    let dataImagen = NSData(contentsOfURL: urlImagen2!)
                    self.portadaView.image = UIImage(data: dataImagen!)
                    portadaLabel.text = "Portada"
                    portadaView.hidden = false
                
                }else{
                    self.portadaLabel.text = "No existe portada"
                    portadaView.hidden = true
                }
                
                //9780553386790
                
                
                
                
                
                

                
            
 
            }
 
                
            catch _ {
                
            }
            
//Comprobar conexión
            
            if datos == nil{
                let alert = UIAlertController(title: "Error", message:"Imposible obtener la informacion requerida. Compruebe su conexión a Internet.", preferredStyle: .Alert)
                alert.addAction(UIAlertAction(title: "Aceptar", style: .Default) { _ in })
                self.presentViewController(alert, animated: true) { }
            }else{
                let texto = NSString(data:datos!, encoding: NSUTF8StringEncoding)
                print(texto)
                
                
//Resultado de la busqueda sin analizar
//                let resultado = String(texto)
//                textResultado.text = resultado
            }
        }
    }
    
//Ocultar Teclado
    
    @IBAction func isbnBuscar(sender: UITextField) {
        consultaIBSN()
        sender.resignFirstResponder()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
}

